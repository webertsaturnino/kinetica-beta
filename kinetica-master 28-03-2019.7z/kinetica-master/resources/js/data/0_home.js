﻿$('.login-button').on('click', function() {
    window.location = "1_data.html";
});
