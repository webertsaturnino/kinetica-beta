# kinetica
